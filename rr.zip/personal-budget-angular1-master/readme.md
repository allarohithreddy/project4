# Info

The path to NGInx main folder:
/usr/share/nginx/html

